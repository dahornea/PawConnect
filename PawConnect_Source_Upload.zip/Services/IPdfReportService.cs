namespace PawConnect.Services;

public interface IPdfReportService
{
    Task<byte[]> GenerateAdoptionRequestReportAsync(int adoptionRequestId);

    Task<byte[]> GenerateAdoptionStatusReportAsync(int adoptionRequestId);

    Task<byte[]> GenerateLowStockResourceReportAsync(int resourceStockId);

    Task<byte[]> GenerateShelterRegistrationRequestReportAsync(int shelterRegistrationRequestId);

    Task<byte[]> GenerateShelterSummaryReportAsync(int shelterId, DateTime fromDate, DateTime toDate);
}
